var result = document.getElementById('result');
var history = document.getElementById('history');
var operations = '';

function press(num) {
    operations += num;
    result.innerText = operations;
}

function reset() {
    operations = '';
    result.innerText = operations;
}

function calculate() {
    try {
        history.innerText += operations + ' = ';
        operations = eval(operations);
        history.innerText += operations + '\n';
        result.innerText = operations;
    } catch {
        result.innerText = 'Error';
        operations = '';
    }
}